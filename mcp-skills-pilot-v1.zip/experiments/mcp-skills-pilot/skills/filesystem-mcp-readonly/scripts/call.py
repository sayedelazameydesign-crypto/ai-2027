#!/usr/bin/env python3
"""Call one tool on the filesystem MCP server (mcpskills-cli style call script).

Stdlib only. Speaks newline-delimited JSON-RPC over stdio to:
    npx -y @modelcontextprotocol/server-filesystem@2.4.0 --read-only <ROOT>

READ-ONLY path: the server is started with ``--read-only`` so write tools
(write_file, edit_file, append_file, copy_file, move_file, create_directory)
are never registered. Version pinned (2.4.0, GHSA-rq2p-q7c4-6g27 fix).
npm integrity: sha512-BoT8Gws5MsetfAey4vDyuzy8WYQES6mGYLSShuqSNGAC0X0NBV4p78/R78KfW4RkxtWz+zxhS9jwhzJrQUTt2Q==

Usage:
    python3 scripts/call.py <tool_name> '<json-arguments>' [ROOT]

Example:
    python3 scripts/call.py list_allowed_directories '{}' /tmp/mcp-fs-root

The server binary/root are the skill's "credentials" (analogous to
mcpskills-cli's ~/.mcps/credentials): edit here or pass ROOT explicitly.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys

PROTOCOL_VERSION = "2025-06-18"


async def call_tool(tool_name: str, arguments: dict, root: str) -> dict:
    proc = await asyncio.create_subprocess_exec(
        "npx", "-y", "@modelcontextprotocol/server-filesystem@2.4.0", "--read-only", root,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    assert proc.stdin and proc.stdout

    async def send(msg: dict) -> None:
        proc.stdin.write((json.dumps(msg, separators=(",", ":")) + "\n").encode())
        await proc.stdin.drain()

    async def recv_until(req_id: int) -> dict:
        while True:
            line = await proc.stdout.readline()
            if not line:
                raise RuntimeError("server closed stdout before response")
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            if msg.get("id") == req_id:
                return msg

    try:
        await send({
            "jsonrpc": "2.0", "id": 0, "method": "initialize",
            "params": {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "filesystem-skill", "version": "1.0"},
            },
        })
        init = await recv_until(0)
        if "error" in init:
            return {"ok": False, "error": init["error"]}
        await send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        await send({
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
        })
        result = await recv_until(1)
        if "error" in result:
            return {"ok": False, "error": result["error"]}
        content = result.get("result", {}).get("content", [])
        texts = [c.get("text", "") for c in content if c.get("type") == "text"]
        return {"ok": not result.get("result", {}).get("isError", False),
                "text": "\n".join(texts)}
    finally:
        try:
            proc.stdin.close()
            await proc.wait()
        except ProcessLookupError:
            pass


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    tool = sys.argv[1]
    try:
        args = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    except json.JSONDecodeError as exc:
        print(f"invalid JSON arguments: {exc}", file=sys.stderr)
        return 2
    root = sys.argv[3] if len(sys.argv) > 3 else os.environ.get("SKILL_FS_ROOT", ".")
    try:
        outcome = asyncio.run(call_tool(tool, args, root))
    except (RuntimeError, OSError) as exc:
        # Server died before/while responding (bad root, crash, missing binary).
        # External response stays generic and bounded; diagnostics (which may
        # contain local paths) go to stderr only, never into the JSON result.
        print(f"diagnostic: {type(exc).__name__}: {exc}", file=sys.stderr)
        outcome = {"ok": False, "error": "server failure: the MCP server did not respond"}
    print(json.dumps(outcome, ensure_ascii=False, indent=2))
    return 0 if outcome.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
